package com.workshop.controller.SpecialLevelManager;

import com.workshop.controller.repository.DataManager;
import com.workshop.controller.repository.factory.PlantFactory;
import com.workshop.model.GameContext;
import com.workshop.model.plants.Plant;
import com.workshop.view.Console;
import java.util.ArrayList;
import java.util.List;

public class ConveyorBeltManager implements LevelManager{
    private final List<Plant> conveyorBelt = new ArrayList<>();
    private double conveyorTimer = 0.0;
    private static final double CONVEYOR_INTERVAL = 4.0;
    private static final int MAX_CAPACITY = 6;
    private PlantFactory plantFactory;

    public ConveyorBeltManager() {
        this.plantFactory = new PlantFactory(DataManager.getInstance());
    }

    @Override
    public void onLevelStart(GameContext context) {
        spawnPlantOnConveyor(context);
        spawnPlantOnConveyor(context);
        spawnPlantOnConveyor(context);
    }

    @Override
    public void onUpdate(double deltaTime, GameContext context) {
        conveyorTimer += deltaTime;
        if (conveyorTimer >= CONVEYOR_INTERVAL) {
            spawnPlantOnConveyor(context);
            conveyorTimer = 0.0;
        }
    }

    @Override
    public boolean canPlant(String plantName, GameContext context) {
        return conveyorBelt.stream().anyMatch(p -> p.getName().equalsIgnoreCase(plantName));
    }

    @Override
    public void onPlantSuccess(Plant plantedPlant, GameContext context) {
        conveyorBelt.remove(plantedPlant);
    }

    private void spawnPlantOnConveyor(GameContext context) {
        if (conveyorBelt.size() < MAX_CAPACITY) {
            List<Plant> pool = context.getLevel().getConveyorPlantPool();
            if (pool != null && !pool.isEmpty()) {
                java.util.Random random = new java.util.Random();

                Plant randomPlantTemplate;
                do {
                    randomPlantTemplate = pool.get(random.nextInt(pool.size()));
                } while (randomPlantTemplate.getName().equalsIgnoreCase("sunflower"));

                Plant newPlantCard = plantFactory.create(randomPlantTemplate.getName());

                conveyorBelt.add(newPlantCard);
                Console.showMessage("New plant added to conveyor belt: " + newPlantCard.getName());
            }
        }
    }

    public List<Plant> getConveyorBelt() {
        return conveyorBelt;
    }
    @Override
    public boolean disableSkySun() {
        return true;
    }
}
