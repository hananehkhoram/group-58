package com.workshop.view.gameplay;

import com.badlogic.gdx.scenes.scene2d.Group;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.workshop.controller.repository.Textures;
import com.workshop.model.GameContext;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

import java.util.ArrayList;

public class BeghouledLayer extends Group {

    private final GameContext ctx;

    private final float gridX;
    private final float gridY;
    private final float cellWidth;
    private final float cellHeight;

    private int selectedRow = -1;
    private int selectedCol = -1;

    private ShapeRenderer shapeRenderer = new ShapeRenderer();

    private ArrayList<Image> matchIcons = new ArrayList<>();

    private int lastMatchCount = 0;

    public BeghouledLayer(
        GameContext ctx,
        float gridX,
        float gridY,
        float gridWidth,
        float gridHeight
    ){

        this.ctx = ctx;

        this.gridX = gridX;
        this.gridY = gridY;

        int columns = ctx.getLevel().getColumns();
        int rows = ctx.getLevel().getRows();

        this.cellWidth = gridWidth / columns;
        this.cellHeight = gridHeight / rows;


        setBounds(
            gridX,
            gridY,
            gridWidth,
            gridHeight
        );

        createMatchIcons();


        addListener(new ClickListener(){

            @Override
            public void clicked(
                InputEvent event,
                float x,
                float y
            ){

                int col =
                    (int)(x / cellWidth);

                int row =
                    ctx.getLevel().getRows()
                        - 1
                        - (int)(y / cellHeight);


                if(selectedRow == -1){

                    selectedRow = row;
                    selectedCol = col;

                } else {

                    boolean result =
                        ctx.getBeghouldManager()
                            .trySwap(
                                selectedCol,
                                selectedRow,
                                col,
                                row
                            );

                    selectedRow = -1;
                    selectedCol = -1;
                }
            }
        });
    }

    @Override
    public void draw(
        com.badlogic.gdx.graphics.g2d.Batch batch,
        float parentAlpha
    ){

        int current =
            ctx.getBeghouldManager()
                .getCurrentMatches();

        while(current > lastMatchCount){

            if(!matchIcons.isEmpty()){

                Image icon =
                    matchIcons.remove(
                        matchIcons.size() - 1
                    );

                icon.remove();
            }

            lastMatchCount++;
        }


        if(selectedRow != -1 && selectedCol != -1){

            batch.end();

            shapeRenderer.setProjectionMatrix(
                getStage()
                    .getCamera()
                    .combined
            );


            shapeRenderer.begin(
                ShapeRenderer.ShapeType.Line
            );


            shapeRenderer.setColor(
                Color.YELLOW
            );


            shapeRenderer.rect(
                gridX + selectedCol * cellWidth,
                gridY
                    + (ctx.getLevel().getRows() - 1 - selectedRow)
                    * cellHeight,
                cellWidth,
                cellHeight
            );


            shapeRenderer.end();

            batch.begin();
        }


        super.draw(batch, parentAlpha);

    }

    private void createMatchIcons(){

        for(int i = 0; i < ctx.getBeghouldManager().getTargetMatches(); i++){

            TextureRegion region =
                Textures.regionOrNull(
                    "IMAGE_EFFECTS_PRIZE_PINATA_80S_PRIZE_PINATA_80S_113X113"
                );

            if(region == null){
                System.out.println("MATCH ICON NOT FOUND");
                continue;
            }

            Image icon = new Image(region);

            icon.setPosition(
                -500,
                getHeight() - 70 - i * 45
            );

            icon.setSize(30,30);

            addActor(icon);

            matchIcons.add(icon);
        }
    }
}
