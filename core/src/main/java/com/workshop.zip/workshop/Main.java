package com.workshop;
import com.workshop.controller.GameEngineController;


//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        GameEngineController engine = new GameEngineController();
        engine.start();
        engine.loop();
    }}
