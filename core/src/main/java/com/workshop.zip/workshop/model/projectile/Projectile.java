package com.workshop.model.projectile;

import com.workshop.model.level.Level;
import com.workshop.model.plants.Plant;
import com.workshop.model.zombie.Zombie;

import java.util.HashSet;
import java.util.Set;

public class Projectile {
    protected int damage;
    protected double x, y;
    protected int row;
    protected double speed;
    protected boolean isActive;
    private final Plant ownerPlant;
    private final ProjectileVisualVariant visualVariant;

    protected final BulletType bulletType;
    protected final TrajectoryType trajectory;
    protected final boolean isFromZombie;

    private final double dirX;
    private final double dirY;

    private int killCount = 0;

    private Damageable homingTarget;
    private final Set<Damageable> alreadyHit = new HashSet<>();

    public Projectile(
        int damage,
        double x,
        double y,
        int row,
        double speed,
        BulletType bulletType,
        TrajectoryType trajectory,
        boolean isFromZombie,
        Plant ownerPlant
    ) {
        this(
            damage,
            x,
            y,
            row,
            speed,
            bulletType,
            trajectory,
            isFromZombie,
            isFromZombie ? -1.0 : 1.0,
            0.0,
            ownerPlant,
            ProjectileVisualVariant.DEFAULT
        );
    }

    public Projectile(
        int damage,
        double x,
        double y,
        int row,
        double speed,
        BulletType bulletType,
        TrajectoryType trajectory,
        boolean isFromZombie,
        Plant ownerPlant,
        ProjectileVisualVariant visualVariant
    ) {
        this(
            damage,
            x,
            y,
            row,
            speed,
            bulletType,
            trajectory,
            isFromZombie,
            isFromZombie ? -1.0 : 1.0,
            0.0,
            ownerPlant,
            visualVariant
        );
    }

    public Projectile(
        int damage,
        double x,
        double y,
        int row,
        double speed,
        BulletType bulletType,
        TrajectoryType trajectory,
        boolean isFromZombie,
        double dirX,
        double dirY,
        Plant ownerPlant
    ) {
        this(
            damage,
            x,
            y,
            row,
            speed,
            bulletType,
            trajectory,
            isFromZombie,
            dirX,
            dirY,
            ownerPlant,
            ProjectileVisualVariant.DEFAULT
        );
    }

    public Projectile(
        int damage,
        double x,
        double y,
        int row,
        double speed,
        BulletType bulletType,
        TrajectoryType trajectory,
        boolean isFromZombie,
        double dirX,
        double dirY,
        Plant ownerPlant,
        ProjectileVisualVariant visualVariant
    ) {
        this.damage = damage;
        this.x = x;
        this.y = y;
        this.row = row;
        this.speed = speed;
        this.isActive = true;
        this.bulletType = bulletType;
        this.trajectory = trajectory;
        this.isFromZombie = isFromZombie;
        this.dirX = dirX;
        this.dirY = dirY;
        this.ownerPlant = ownerPlant;
        this.visualVariant = visualVariant == null
            ? ProjectileVisualVariant.DEFAULT
            : visualVariant;
    }

    public void update(double time) {
        if (!isActive) return;

        switch (trajectory) {
            case HOMING:
                if (homingTarget == null || homingTarget.isDead()) {
                    isActive = false;
                    return;
                }
                double toTargetX = homingTarget.getX() - x;
                double toTargetY = homingTarget.getRow() - y;
                double dist = Math.hypot(toTargetX, toTargetY);
                if (dist > 1e-6) {
                    x += (toTargetX / dist) * speed * time;
                    y += (toTargetY / dist) * speed * time;
                    row = (int) Math.round(y);
                }
                break;
            default:
                x += dirX * speed * time;
                if (dirY != 0) {
                    y += dirY * speed * time;
                    row = (int) Math.round(y);
                }
                break;
        }
    }

    public void onHit(Damageable target) {
        if (trajectory == TrajectoryType.PIERCING && alreadyHit.contains(target)) {
            return;
        }

        if (visualVariant == ProjectileVisualVariant.BUTTER) {
            target.takeDamage(damage);
            if (target instanceof Zombie zombie) {
                zombie.applyButter();
            }
        } else switch (bulletType) {
            case MISSILE:
                target.takeDamage(damage);
                break;

            case FIRE:
                if ("Imp Dragon".equals(target.name())) { break; }
                target.takeDamage(damage * 2);
                target.meltIce();
                break;

            case POISON:
                target.takeArmorPiercingDamage(damage);
                break;

            case ICE:
                target.takeDamage(damage);
                if ("Dodo".equals(target.name()) || "Hunter".equals(target.name()) ||
                    "Troglobite".equals(target.name())) { break; }
                target.applySlowOrFreeze();
                break;

            case ELECTRIC:
                target.takeDamage(Integer.MAX_VALUE);
                break;

            case OCTOPUS:
                if (target instanceof Plant plant) {
                    plant.setOctopused(true);
                } else {
                    target.applySlowOrFreeze();
                }
                break;

            case MAGIC:
            case SMOKE:
            case NORMAL:
            default:
                target.takeDamage(damage);
                break;
        }

        if (trajectory == TrajectoryType.PIERCING) {
            alreadyHit.add(target);
        } else {
            isActive = false;
        }
    }

    public void setHomingTarget(Damageable target) {
        this.homingTarget = target;
    }

    public void deactivate() { this.isActive = false; }

    public void bounceLane(int newRow) {
        this.row = newRow;
        this.y = newRow;
    }

    public double getX() { return x; }
    public int getRow() { return row; }
    public boolean isActive() { return isActive; }
    public int getDamage() { return damage; }
    public double getSpeed() { return speed; }
    public double getY() { return y; }
    public BulletType getBulletType() { return bulletType; }
    public TrajectoryType getTrajectory() { return trajectory; }
    public boolean isFromZombie() { return isFromZombie; }
    public Plant getOwnerPlant() { return ownerPlant; }
    public ProjectileVisualVariant getVisualVariant() { return visualVariant; }
    public boolean isOutOfBounds() {
        return this.getRow() < 0 || this.getRow() >= Level.ROWS || this.getX() < -1 || this.getX() > Level.COLS;
    }
    public void incrementKillCount() { killCount++; }
    public int getKillCount() { return killCount; }
}
