package com.workshop.model.level;

public enum LevelType {
    NORMAL,
    CONVEYOR_BELT,
    DEADLINE,
    LOCKED_PLANTS,
    LOVE_YOUR_PLANTS,
    NIGHT_OPS,
    PLANT_WHAT_YOU_GET,
    SAVE_QUR_SEEDS,
    TIMED_WAR,
    BOSS_FIGHT,
    Wallnuts_MG,
    Vase_MG,
    Izambie_MG,
    Beghouled_MG,
    Zombotany_MG,
    BONUS
}
