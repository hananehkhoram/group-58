package com.workshop.model.mechanisms;

public enum TerrainType {
    NORMAL,
    GRAVE,
    CRATER,
    FROZEN,
    SLIPPERY_UP,
    SLIPPERY_DOWN,
    WATER,
    LOW_TIDE,
    NECROMANCY,
    BURNED
}
