package com.workshop.model.menus.allmenus;

import com.workshop.controller.repository.DataManager;
import com.workshop.model.GameContext;
import com.workshop.model.menus.BaseMenu;
import com.workshop.model.menus.MenuType;
import com.workshop.model.user.SecurityQuestions;
import com.workshop.model.user.UserManager;
import com.workshop.net.GameClient;
import com.workshop.net.NetResponse;


public class RegisterMenu extends BaseMenu {
    private UserManager um;
    private String pendingUsername;
    private String pendingPassword;

    public RegisterMenu(GameContext ctx) {
        super(ctx, MenuType.REGISTER);
        this.um = UserManager.getInstance();
        this.name = "Register menu";
    }


    public String register(String username, String password, String passwordConfirm,
                           String nickName, String email,String gender){
        if (!um.isUsernameValid(username)) return "Invalid username format.";
        if (um.doesUserExist(username)) return "Username already exists.";
        if (!um.isPasswordValid(password)) return "Invalid password format.";
        String passwordValidation = um.isPasswordStrong(password);
        if (!passwordValidation.equals("ok")) return passwordValidation;
        if (!um.doesPasswordsMatch(password,passwordConfirm)) {
            return "Passwords do not match! please try again.";
        }
        if (!um.isNickNameValid(nickName)) return "Invalid nickname.";
        if (!um.isEmailValid(email)) return "Invalid email format.";
        if (!gender.equalsIgnoreCase("female") && !gender.equalsIgnoreCase("male"))
            return "Invalid gender type.";

        GameClient client = GameClient.get();
        if (client.isConnected()) {
            NetResponse response = client.register(username, password, nickName, email, gender);
            if (!response.ok) {
                return response.message;
            }
        } else if (um.doesUserExist(username)) {
            return "Username already exists.";
        }

        um.register(username,password,nickName,email,gender);

        StringBuilder sb = new StringBuilder();
        sb.append("Please pick a security question: \n");
        for (int i = 0; i < SecurityQuestions.values().length; i++) {
            SecurityQuestions question = SecurityQuestions.getQuestionById(i + 1);
            sb.append(question.getId()).append(": ").append(question.getQuestionText()).append("\n");
        }

        pendingUsername = username;
        pendingPassword = password;

        return sb.toString();

    }
    public String pickQuestion(
        int questionNumber,
        String answer,
        String answerConfirm
    ) {
        SecurityQuestions selectedQuestion =
            SecurityQuestions.getQuestionById(questionNumber);

        if (selectedQuestion == null) {
            return "Invalid question number! Please choose a valid number.";
        }

        if (!answer.equalsIgnoreCase(answerConfirm)) {
            return "Answers don't mach!please try again.\n";
        }

        if (answer.isBlank()) {
            return "Security answer cannot be empty.";
        }

        GameClient client = GameClient.get();

        if (client.isConnected()) {
            NetResponse response = client.setSecurityQuestion(
                pendingUsername,
                pendingPassword,
                questionNumber,
                answer
            );

            if (!response.ok) {
                return response.message;
            }
        }

        um.addQuestion(selectedQuestion, answer);
        DataManager.getInstance().saveUser();

        pendingUsername = null;
        pendingPassword = null;

        return "Registered successfully.";
    }

}
